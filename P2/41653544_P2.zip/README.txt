Given:
	- the starter code here is the solution to P1 (basic classes: ver1 code: Animal, Llama, Cow, Duck, Farm)

Required: 
	1) polymorphism and instanceof
	2) abstract classes and interfaces
	3) Testing