public class A7 {
    public static void main(String[] args) {
        PatientManager patientManager = new PatientManager();
        patientManager.start();
    }
}
